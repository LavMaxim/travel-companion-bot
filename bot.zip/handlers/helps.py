from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from states import HelpStates
from loader import i18n
from keyboards.help import (
    help_kb,
    faq_categories_kb,
    faq_answers_kb,
    instruction_kb,
    feedback_type_kb,
    feedback_cancel_kb
)

router = Router()

@router.message(F.text == "🆘 Помощь")
async def show_help_menu(message: Message):
    text = i18n.gettext("help.main")
    await message.answer(text, reply_markup=help_kb())

@router.callback_query(F.data == "help:faq")
async def show_faq_categories(cb: CallbackQuery):
    await cb.message.edit_text(
        i18n.gettext("help.faq_categories"),
        reply_markup=faq_categories_kb()
    )
    await cb.answer()

@router.callback_query(F.data.startswith("faq:category:"))
async def show_faq_questions(cb: CallbackQuery):
    category = cb.data.split(':')[-1]
    text = i18n.gettext(f"faq.category.{category}.questions")
    await cb.message.edit_text(text, reply_markup=faq_answers_kb(category))
    await cb.answer()

@router.callback_query(F.data.startswith("faq:answer:"))
async def show_faq_answer(cb: CallbackQuery):
    _, _, category, qkey = cb.data.split(':')
    text = i18n.gettext(f"faq.category.{category}.answers.{qkey}")
    await cb.message.answer(text, reply_markup=help_kb())
    await cb.answer()

@router.callback_query(F.data == "help:instruction")
async def show_instruction(cb: CallbackQuery, state: FSMContext):
    cards = i18n.gettext("help.instructions.cards").split("||")
    await state.update_data(instr_idx=0)
    await cb.message.edit_text(
        cards[0],
        reply_markup=instruction_kb(current=1, total=len(cards))
    )
    await cb.answer()

@router.callback_query(F.data == "instr:next")
async def instruction_next(cb: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    idx = data.get('instr_idx', 0) + 1
    cards = i18n.gettext("help.instructions.cards").split("||")
    if idx < len(cards):
        await state.update_data(instr_idx=idx)
        await cb.message.edit_text(
            cards[idx],
            reply_markup=instruction_kb(current=idx+1, total=len(cards))
        )
    else:
        await cb.message.edit_text(
            i18n.gettext("help.instruction_end"),
            reply_markup=help_kb()
        )
    await cb.answer()

@router.callback_query(F.data == "help:feedback")
async def start_feedback(cb: CallbackQuery, state: FSMContext):
    await state.set_state(HelpStates.choose_type)
    await cb.message.edit_text(
        i18n.gettext("help.feedback.choose_type"),
        reply_markup=feedback_type_kb()
    )
    await cb.answer()

@router.callback_query(F.data.startswith("feedback:type:"))
async def choose_feedback_type(cb: CallbackQuery, state: FSMContext):
    ftype = cb.data.split(':')[-1]
    await state.update_data(feedback_type=ftype)
    await state.set_state(HelpStates.collect)
    await cb.message.edit_text(
        i18n.gettext("help.feedback.prompt"),
        reply_markup=feedback_cancel_kb()
    )
    await cb.answer()

@router.message(HelpStates.collect)
async def collect_feedback(message: Message, state: FSMContext):
    data = await state.get_data()
    ftype = data['feedback_type']
    owner_id = int(i18n.gettext("help.owner_id"))
    await message.bot.send_message(
        owner_id,
        f"🆘 [{ftype.upper()}] from @{message.from_user.username} ({message.from_user.id}): {message.text}"
    )
    await message.answer(
        i18n.gettext("help.feedback.thanks"),
        reply_markup=help_kb()
    )
    await state.clear()

@router.callback_query(F.data == "feedback:cancel")
async def cancel_feedback(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    await cb.message.edit_text(
        i18n.gettext("help.feedback.cancelled"),
        reply_markup=help_kb()
    )
    await cb.answer()